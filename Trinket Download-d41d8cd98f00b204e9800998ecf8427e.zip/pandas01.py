import pandas

file = pandas.read_csv("country_data.csv")

print(file)