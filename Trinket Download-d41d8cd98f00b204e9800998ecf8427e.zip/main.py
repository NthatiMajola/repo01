print("my first python file/scirpt/recipe")
density = 1000

Density = 900

mass_kg = 50

# three main types of data

import pandas

file = pandas.read_csv("country_data.csv")

print(file) 
